"""
predict.py
----------
Loads the saved fine-tuned BERT model and exposes a simple predict() function
used by both the FastAPI server and standalone scripts.
"""

from __future__ import annotations
import torch
import torch.nn.functional as F
from transformers import BertForSequenceClassification, BertTokenizer

SAVE_DIR = "saved_model"
ID2LABEL = {0: "positive", 1: "neutral", 2: "negative"}
MAX_LENGTH = 128


class SentimentPredictor:
    """Singleton-style wrapper so the model is loaded once per process."""

    _instance: "SentimentPredictor | None" = None

    def __new__(cls, model_dir: str = SAVE_DIR):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._load(model_dir)
        return cls._instance

    def _load(self, model_dir: str):
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.tokenizer = BertTokenizer.from_pretrained(model_dir)
        self.model = BertForSequenceClassification.from_pretrained(model_dir)
        self.model.to(self.device)
        self.model.eval()
        print(f"Model loaded from '{model_dir}' on {self.device}")

    @torch.no_grad()
    def predict(self, text: str) -> dict:
        encoding = self.tokenizer(
            text,
            max_length=MAX_LENGTH,
            padding="max_length",
            truncation=True,
            return_tensors="pt",
        )
        input_ids = encoding["input_ids"].to(self.device)
        attention_mask = encoding["attention_mask"].to(self.device)

        logits = self.model(input_ids=input_ids, attention_mask=attention_mask).logits
        probs = F.softmax(logits, dim=1).squeeze(0).tolist()

        label_id = int(torch.argmax(logits, dim=1).item())
        return {
            "label": ID2LABEL[label_id],
            "confidence": round(probs[label_id], 4),
            "probabilities": {
                "positive": round(probs[0], 4),
                "neutral": round(probs[1], 4),
                "negative": round(probs[2], 4),
            },
        }


# ─── Quick CLI test ───────────────────────────────────────────────────────────
if __name__ == "__main__":
    import sys

    text = " ".join(sys.argv[1:]) if len(sys.argv) > 1 else "This product is absolutely fantastic!"
    predictor = SentimentPredictor()
    result = predictor.predict(text)
    print(result)
