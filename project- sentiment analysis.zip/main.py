"""
main.py
-------
FastAPI REST API for the BERT sentiment classifier.

Endpoints:
    POST /predict          - Single review prediction
    POST /predict/batch    - Batch prediction (up to 32 texts)
    GET  /health           - Health check
"""

from __future__ import annotations
import sys
import os

# Allow imports from the model directory when running from api/
sys.path.append(os.path.join(os.path.dirname(__file__), "..", "model"))

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from typing import List
import time

from predict import SentimentPredictor


# ─── App setup ────────────────────────────────────────────────────────────────

app = FastAPI(
    title="BERT Sentiment Analysis API",
    description="3-class sentiment classifier (positive / neutral / negative) fine-tuned on Amazon Product Reviews.",
    version="1.0.0",
)

predictor: SentimentPredictor | None = None


@app.on_event("startup")
async def load_model():
    global predictor
    predictor = SentimentPredictor(model_dir=os.getenv("MODEL_DIR", "saved_model"))


# ─── Schemas ──────────────────────────────────────────────────────────────────

class ReviewRequest(BaseModel):
    text: str = Field(..., min_length=1, max_length=2048, example="This product is absolutely amazing!")


class PredictionResponse(BaseModel):
    label: str
    confidence: float
    probabilities: dict
    latency_ms: float


class BatchRequest(BaseModel):
    texts: List[str] = Field(..., min_items=1, max_items=32)


class BatchResponse(BaseModel):
    results: List[PredictionResponse]
    total_latency_ms: float


# ─── Routes ───────────────────────────────────────────────────────────────────

@app.get("/health")
def health():
    return {"status": "ok", "model_loaded": predictor is not None}


@app.post("/predict", response_model=PredictionResponse)
def predict(req: ReviewRequest):
    if predictor is None:
        raise HTTPException(status_code=503, detail="Model not loaded yet.")
    t0 = time.perf_counter()
    result = predictor.predict(req.text)
    latency = round((time.perf_counter() - t0) * 1000, 2)
    return PredictionResponse(**result, latency_ms=latency)


@app.post("/predict/batch", response_model=BatchResponse)
def predict_batch(req: BatchRequest):
    if predictor is None:
        raise HTTPException(status_code=503, detail="Model not loaded yet.")
    t0 = time.perf_counter()
    results = []
    for text in req.texts:
        t1 = time.perf_counter()
        result = predictor.predict(text)
        latency = round((time.perf_counter() - t1) * 1000, 2)
        results.append(PredictionResponse(**result, latency_ms=latency))
    total_latency = round((time.perf_counter() - t0) * 1000, 2)
    return BatchResponse(results=results, total_latency_ms=total_latency)
