"""
dataset.py
----------
PyTorch Dataset wrapper for tokenised BERT inputs.
"""

import torch
from torch.utils.data import Dataset


class SentimentDataset(Dataset):
    """Tokenises raw texts on-the-fly using a HuggingFace tokenizer."""

    LABEL2ID = {"positive": 0, "neutral": 1, "negative": 2}
    ID2LABEL = {v: k for k, v in LABEL2ID.items()}

    def __init__(self, texts, labels, tokenizer, max_length: int = 128):
        self.texts = texts
        self.labels = labels
        self.tokenizer = tokenizer
        self.max_length = max_length

    def __len__(self):
        return len(self.texts)

    def __getitem__(self, idx):
        encoding = self.tokenizer(
            str(self.texts[idx]),
            max_length=self.max_length,
            padding="max_length",
            truncation=True,
            return_tensors="pt",
        )
        return {
            "input_ids": encoding["input_ids"].squeeze(0),
            "attention_mask": encoding["attention_mask"].squeeze(0),
            "label": torch.tensor(self.labels[idx], dtype=torch.long),
        }
