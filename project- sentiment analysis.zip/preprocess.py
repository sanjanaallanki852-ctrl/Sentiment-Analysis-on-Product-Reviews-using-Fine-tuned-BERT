"""
preprocess.py
-------------
Loads the Amazon Product Reviews dataset, maps star ratings to
sentiment labels, and saves train/val/test splits as CSV files.
"""

import pandas as pd
from sklearn.model_selection import train_test_split
from datasets import load_dataset


def map_label(rating: int) -> str:
    if rating >= 4:
        return "positive"
    elif rating == 3:
        return "neutral"
    else:
        return "negative"


def load_and_preprocess(num_samples: int = 50000, seed: int = 42) -> pd.DataFrame:
    print("Loading dataset from HuggingFace hub...")
    dataset = load_dataset("amazon_polarity", split="train")

    df = pd.DataFrame(dataset).sample(n=num_samples, random_state=seed).reset_index(drop=True)

    # amazon_polarity has labels 0 (neg) and 1 (pos); derive neutral from short reviews
    # For a 3-class setup we re-label: use content length as a proxy for neutral
    def remap(row):
        text = row["content"]
        label = row["label"]
        if label == 1 and len(text.split()) < 12:
            return "neutral"
        if label == 0 and len(text.split()) < 12:
            return "neutral"
        return "positive" if label == 1 else "negative"

    df["text"] = df["title"] + " " + df["content"]
    df["sentiment"] = df.apply(remap, axis=1)
    df = df[["text", "sentiment"]].dropna()

    label_map = {"positive": 0, "neutral": 1, "negative": 2}
    df["label"] = df["sentiment"].map(label_map)

    print(f"Label distribution:\n{df['sentiment'].value_counts()}\n")
    return df


def split_and_save(df: pd.DataFrame, output_dir: str = "data"):
    train, temp = train_test_split(df, test_size=0.2, random_state=42, stratify=df["label"])
    val, test = train_test_split(temp, test_size=0.5, random_state=42, stratify=temp["label"])

    train.to_csv(f"{output_dir}/train.csv", index=False)
    val.to_csv(f"{output_dir}/val.csv", index=False)
    test.to_csv(f"{output_dir}/test.csv", index=False)

    print(f"Train: {len(train)} | Val: {len(val)} | Test: {len(test)}")
    print("Saved to data/train.csv, val.csv, test.csv")


if __name__ == "__main__":
    df = load_and_preprocess(num_samples=50000)
    split_and_save(df, output_dir="data")
