"""
train.py
--------
Fine-tunes bert-base-uncased on the preprocessed Amazon sentiment dataset
for 3-class classification (positive / neutral / negative).

Usage:
    python model/train.py --epochs 3 --batch_size 32 --lr 2e-5
"""

import argparse
import os
import time

import pandas as pd
import torch
from torch.utils.data import DataLoader
from transformers import BertForSequenceClassification, BertTokenizer, get_linear_schedule_with_warmup
from sklearn.metrics import accuracy_score, f1_score, classification_report

from dataset import SentimentDataset


# ─── Config ──────────────────────────────────────────────────────────────────

LABEL2ID = {"positive": 0, "neutral": 1, "negative": 2}
ID2LABEL = {v: k for k, v in LABEL2ID.items()}
MODEL_NAME = "bert-base-uncased"
SAVE_DIR = "saved_model"


# ─── Helpers ─────────────────────────────────────────────────────────────────

def load_split(path: str):
    df = pd.read_csv(path)
    texts = df["text"].tolist()
    labels = df["label"].tolist()
    return texts, labels


def evaluate(model, loader, device):
    model.eval()
    all_preds, all_labels = [], []
    total_loss = 0.0

    with torch.no_grad():
        for batch in loader:
            input_ids = batch["input_ids"].to(device)
            attention_mask = batch["attention_mask"].to(device)
            labels = batch["label"].to(device)

            outputs = model(input_ids=input_ids, attention_mask=attention_mask, labels=labels)
            total_loss += outputs.loss.item()

            preds = torch.argmax(outputs.logits, dim=1).cpu().tolist()
            all_preds.extend(preds)
            all_labels.extend(labels.cpu().tolist())

    avg_loss = total_loss / len(loader)
    acc = accuracy_score(all_labels, all_preds)
    f1 = f1_score(all_labels, all_preds, average="weighted")
    return avg_loss, acc, f1, all_preds, all_labels


# ─── Training loop ────────────────────────────────────────────────────────────

def train(args):
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Using device: {device}\n")

    # Load tokenizer & model
    tokenizer = BertTokenizer.from_pretrained(MODEL_NAME)
    model = BertForSequenceClassification.from_pretrained(
        MODEL_NAME,
        num_labels=3,
        id2label=ID2LABEL,
        label2id=LABEL2ID,
    )
    model.to(device)

    # Datasets & loaders
    train_texts, train_labels = load_split("data/train.csv")
    val_texts, val_labels = load_split("data/val.csv")

    train_ds = SentimentDataset(train_texts, train_labels, tokenizer, max_length=args.max_length)
    val_ds = SentimentDataset(val_texts, val_labels, tokenizer, max_length=args.max_length)

    train_loader = DataLoader(train_ds, batch_size=args.batch_size, shuffle=True, num_workers=4)
    val_loader = DataLoader(val_ds, batch_size=args.batch_size, shuffle=False, num_workers=4)

    # Optimiser & scheduler
    optimizer = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=0.01)
    total_steps = len(train_loader) * args.epochs
    scheduler = get_linear_schedule_with_warmup(
        optimizer,
        num_warmup_steps=int(0.1 * total_steps),
        num_training_steps=total_steps,
    )

    best_val_f1 = 0.0
    print(f"Training for {args.epochs} epochs — {len(train_loader)} steps/epoch\n")

    for epoch in range(1, args.epochs + 1):
        model.train()
        epoch_loss = 0.0
        t0 = time.time()

        for step, batch in enumerate(train_loader, 1):
            input_ids = batch["input_ids"].to(device)
            attention_mask = batch["attention_mask"].to(device)
            labels = batch["label"].to(device)

            optimizer.zero_grad()
            outputs = model(input_ids=input_ids, attention_mask=attention_mask, labels=labels)
            loss = outputs.loss
            loss.backward()

            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            optimizer.step()
            scheduler.step()

            epoch_loss += loss.item()

            if step % 100 == 0:
                avg = epoch_loss / step
                elapsed = time.time() - t0
                print(f"  Epoch {epoch} | Step {step}/{len(train_loader)} | Loss {avg:.4f} | {elapsed:.0f}s")

        # Validation
        val_loss, val_acc, val_f1, _, _ = evaluate(model, val_loader, device)
        print(f"\nEpoch {epoch} complete | Val Loss {val_loss:.4f} | Val Acc {val_acc:.4f} | Val F1 {val_f1:.4f}")

        if val_f1 > best_val_f1:
            best_val_f1 = val_f1
            os.makedirs(SAVE_DIR, exist_ok=True)
            model.save_pretrained(SAVE_DIR)
            tokenizer.save_pretrained(SAVE_DIR)
            print(f"  ✓ New best model saved (F1={best_val_f1:.4f})\n")


def test(args):
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    tokenizer = BertTokenizer.from_pretrained(SAVE_DIR)
    model = BertForSequenceClassification.from_pretrained(SAVE_DIR)
    model.to(device)

    test_texts, test_labels = load_split("data/test.csv")
    test_ds = SentimentDataset(test_texts, test_labels, tokenizer, max_length=args.max_length)
    test_loader = DataLoader(test_ds, batch_size=args.batch_size, shuffle=False, num_workers=4)

    _, acc, f1, preds, labels = evaluate(model, test_loader, device)
    print(f"\n── Test Results ──")
    print(f"Accuracy : {acc:.4f}")
    print(f"Weighted F1 : {f1:.4f}")
    print("\nClassification Report:")
    print(classification_report(labels, preds, target_names=["positive", "neutral", "negative"]))


# ─── Entry point ──────────────────────────────────────────────────────────────

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Fine-tune BERT for sentiment analysis")
    parser.add_argument("--epochs", type=int, default=3)
    parser.add_argument("--batch_size", type=int, default=32)
    parser.add_argument("--lr", type=float, default=2e-5)
    parser.add_argument("--max_length", type=int, default=128)
    parser.add_argument("--test", action="store_true", help="Run test evaluation after training")
    args = parser.parse_args()

    train(args)
    if args.test:
        test(args)
