# Sentiment Analysis on Product Reviews using Fine-tuned BERT

> 3-class sentiment classifier (Positive / Neutral / Negative) fine-tuned on 50,000 Amazon Product Reviews, deployed as a containerised REST API.

---

## Results

| Model | Accuracy | Weighted F1 |
|-------|----------|-------------|
| **Fine-tuned BERT** (bert-base-uncased) | **89%** | **0.88** |
| Baseline — TF-IDF + Logistic Regression | 78% | 0.77 |

---

## Project Structure

```
sentiment-bert/
├── data/
│   └── preprocess.py        # Download & split Amazon Reviews dataset
├── model/
│   ├── dataset.py           # PyTorch Dataset class
│   ├── train.py             # Fine-tuning loop
│   └── predict.py           # Inference wrapper (singleton)
├── api/
│   └── main.py              # FastAPI application
├── notebooks/
│   └── eda_and_evaluation.ipynb
├── Dockerfile
├── docker-compose.yml
├── requirements.txt
└── README.md
```

---

## Quickstart

### 1 — Install dependencies

```bash
python -m venv venv
source venv/bin/activate          # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

### 2 — Preprocess the dataset

```bash
python data/preprocess.py
# Outputs: data/train.csv  data/val.csv  data/test.csv
```

### 3 — Fine-tune BERT

```bash
python model/train.py --epochs 3 --batch_size 32 --lr 2e-5 --test
# Best model weights saved to: saved_model/
```

Training takes ~45 min on a single A100 GPU / ~3 hrs on CPU.

### 4 — Run the API locally

```bash
uvicorn api.main:app --reload --port 8000
```

### 5 — Run with Docker

```bash
# Build & start
docker-compose up --build

# Or manually
docker build -t bert-sentiment .
docker run -p 8000:8000 bert-sentiment
```

---

## API Reference

### `POST /predict`

```bash
curl -X POST http://localhost:8000/predict \
  -H "Content-Type: application/json" \
  -d '{"text": "This product is absolutely amazing!"}'
```

**Response:**

```json
{
  "label": "positive",
  "confidence": 0.94,
  "probabilities": {
    "positive": 0.94,
    "neutral": 0.04,
    "negative": 0.02
  },
  "latency_ms": 38.5
}
```

### `POST /predict/batch`

```bash
curl -X POST http://localhost:8000/predict/batch \
  -H "Content-Type: application/json" \
  -d '{"texts": ["Great product!", "It is okay.", "Terrible quality."]}'
```

### `GET /health`

```bash
curl http://localhost:8000/health
# {"status": "ok", "model_loaded": true}
```

Interactive docs available at `http://localhost:8000/docs` (Swagger UI).

---

## Model Details

| Detail | Value |
|--------|-------|
| Base model | `bert-base-uncased` |
| Dataset | Amazon Product Reviews (50,000 samples) |
| Classes | Positive (0) · Neutral (1) · Negative (2) |
| Max token length | 128 |
| Epochs | 3 |
| Batch size | 32 |
| Learning rate | 2e-5 (linear warmup + decay) |
| Optimiser | AdamW (weight decay 0.01) |

---

## Tech Stack

- **Python 3.10**
- **HuggingFace Transformers** — BERT tokenizer & model
- **PyTorch** — training loop
- **FastAPI + Uvicorn** — REST API
- **Docker** — containerisation
- **scikit-learn** — metrics & baseline

---

## License

MIT
